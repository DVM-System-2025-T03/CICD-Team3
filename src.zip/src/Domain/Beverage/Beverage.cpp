#include "Beverage.h"

bool Beverage::hasEnoughStock(int quantity){
    return false;
}

bool Beverage::reduceQuantity(int quantity){
    return false;
}

int Beverage::getId(){
    return id;
}

int Beverage::getPrice(){
    return price;
}