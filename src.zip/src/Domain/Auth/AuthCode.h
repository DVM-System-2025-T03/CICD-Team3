#pragma once

class AuthCode{

};