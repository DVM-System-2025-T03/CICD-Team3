#include "CreditCard.h"

bool CreditCard::validateBalance(int price) {
    return false;
}

void CreditCard::reduceBalance(int price) {
    
}