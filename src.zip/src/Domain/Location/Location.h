
#pragma once
#include <iostream>

using namespace std;

class Location{
    private:
        double x;
        double y;
};