#pragma once
class RequestStockDTO{
    
};