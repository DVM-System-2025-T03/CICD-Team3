class ResponsePrePaymentDTO{
    
};