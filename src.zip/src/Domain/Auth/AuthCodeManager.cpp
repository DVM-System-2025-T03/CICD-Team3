#include "AuthCodeManager.h"

bool AuthCodeManager::validateAuthCode(string authCode) {
    return false;
}

int AuthCodeManager::getBeverageId(string authCode) {
    return 0;
}

void AuthCodeManager::saveAuthCode(string authCode) {
    
}

string AuthCodeManager::generateAuthCode() {
    return "";
}