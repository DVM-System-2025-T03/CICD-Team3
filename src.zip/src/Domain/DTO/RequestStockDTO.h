class RequestStockDTO{
    
};