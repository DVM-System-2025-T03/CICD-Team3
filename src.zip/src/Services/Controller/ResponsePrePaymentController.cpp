#include "ResponsePrePaymentController.h"

ResponsePrePaymentDTO ResponsePrePaymentController::responsePrePay(int beverageId, int quantity, AuthCode authCode) {
    return ResponsePrePaymentDTO();
}