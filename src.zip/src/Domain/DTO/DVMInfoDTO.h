#pragma once
class DVMInfoDTO{
    
};