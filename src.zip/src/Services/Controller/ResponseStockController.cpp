#include "ResponseStockController.h"

ResponseStockDTO ResponseStockController::responseBeverageStock(int beverageId, int quantity) {
    return ResponseStockDTO();  // 스켈레톤
}