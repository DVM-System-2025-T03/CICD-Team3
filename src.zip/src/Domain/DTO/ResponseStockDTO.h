#pragma once
class ResponseStockDTO{
    
};