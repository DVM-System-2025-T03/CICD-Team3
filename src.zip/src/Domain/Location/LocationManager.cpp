#include "LocationManager.h"

DVMInfoDTO LocationManager::calculateNearest(list<ResponseStockDTO> responseList) {
    return DVMInfoDTO();
}

Location LocationManager::getLocation() {
    return Location();
}