class DVMInfoDTO{
    
};