#include "EnterAuthCodeController.h"

Beverage EnterAuthCodeController::enterAuthCode(string authCode) {
    return Beverage();  // 스켈레톤 반환
}