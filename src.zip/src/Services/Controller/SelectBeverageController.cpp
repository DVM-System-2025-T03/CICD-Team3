#include "SelectBeverageController.h"

void SelectBeverageController::selectBeverage(int beverageId, int quantity) {
    
}