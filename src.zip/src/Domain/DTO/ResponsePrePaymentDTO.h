#pragma once
class ResponsePrePaymentDTO{
    
};