#include "RequestPrePaymentController.h"

void RequestPrePaymentController::enterPrePayIntention(bool intention) {
    
}

string RequestPrePaymentController::enterCardNumber(string cardNumber) {
    return "";
}