#include "RequestPaymentController.h"

Beverage RequestPaymentController::enterCardNumber(string cardNumber) {
    return Beverage();
}